import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner term = new Scanner(System.in);

        int n = Integer.parseInt(term.nextLine());


        Car car = new Car();

        for (int i = 0; i < n; i++) {
            String[] parts = term.nextLine().split("\\s+");

            car.setBrand(parts[0]);
            car.setModel(parts[1]);
            car.setHorsePower(Integer.parseInt(parts[2]));

            CarInfo carInfo = new CarInfo(car.getBrand(), car.getModel(), car.getHorsePower());
        }
    }
}
