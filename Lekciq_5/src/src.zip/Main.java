import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner term = new Scanner(System.in);

        int n = Integer.parseInt(term.nextLine());

        for (int i = 0; i < n; i++) {
            String[] parts = term.nextLine().split("\\s+");

            if (parts.length == 1){
                Car car = new Car(parts[0]);
                car.setBrand(parts[0]);
                CarInfo carInfo = new CarInfo(car.getBrand(), car.getModel(), car.getHorsePower());
            } else if (parts.length == 2){
                Car car = new Car(parts[0], parts[1]);
                car.setBrand(parts[0]);
                car.setModel(parts[1]);
                CarInfo carInfo = new CarInfo(car.getBrand(), car.getModel(), car.getHorsePower());
            } else {
                Car car = new Car(parts[0], parts[1], Integer.parseInt(parts[2]));
                car.setBrand(parts[0]);
                car.setModel(parts[1]);
                car.setHorsePower(Integer.parseInt(parts[2]));
                CarInfo carInfo = new CarInfo(car.getBrand(), car.getModel(), car.getHorsePower());
            }
        }
    }
}
