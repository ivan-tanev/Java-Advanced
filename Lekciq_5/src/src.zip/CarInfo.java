public class CarInfo {

    public CarInfo(String carBrand, String carModel, int horsePower){
        System.out.println(String.format("The car is: %s %s - %d HP.",
                carBrand, carModel, horsePower));
    }
}
